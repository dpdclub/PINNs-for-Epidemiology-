import os
from os import system


window_list = [3, 5, 7, 10, 12, 15]

for window_size in window_list:
    print("window size: %d weeks" % (window_size))
    respath = 'results/window=%d' % (window_size)
    os.makedirs(respath, exist_ok=True)


    print("Start running for one week: ")
    os.system("python one_week.py --windowsize=%d" % (window_size))
    os.system("python generate_one_week_predictions.py --windowsize=%d" % (window_size))


    print("Start running for two week: ")
    os.system("python two_week.py --windowsize=%d" % (window_size))
    os.system("python generate_two_week_predictions.py --windowsize=%d" % (window_size))


    print("Start running for three week: ")
    os.system("python three_week.py --windowsize=%d" % (window_size))
    os.system("python generate_three_week_predictions.py --windowsize=%d" % (window_size))


    print("Start running for four week: ")
    os.system("python four_week.py --windowsize=%d" % (window_size))
