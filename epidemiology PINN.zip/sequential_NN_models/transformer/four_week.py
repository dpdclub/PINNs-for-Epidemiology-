import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
import scipy.io as sio
import warnings
from argparse import ArgumentParser


parser = ArgumentParser()
parser.add_argument("--windowsize", type=int, default=5)
arguments = parser.parse_args()
print(arguments)

warnings.filterwarnings('ignore')
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


predictions = np.zeros([70, 4])
for n in range(20, 90):
    filename=f"middata/three_week_{n}.mat"
    data = sio.loadmat(filename)

    Zr_data = data["cases"].T  

    Dr_data = data["deaths"].T  

    A_data = data["hospitalized"].T  
   
    Zr_data[Zr_data <= 0] = 0
    Dr_data[Dr_data <= 0] = 0
    A_data[A_data <= 0] = 0

    data = np.concatenate([Zr_data[:n], Dr_data[:n], A_data[:n]], axis=1).T    
    data_T = data.T  
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data_T) 
  
    data_scaled = data_scaled.T


    # window_size = 7
    window_size = arguments.windowsize

    X_list = []
    y_list = []
   
    for i in range(n - window_size):
        
        X_list.append(data_scaled[:, i:i+window_size].T)
        
        y_list.append(data_scaled[:, i+window_size])
    X = np.stack(X_list, axis=0)  
    y = np.stack(y_list, axis=0)  

    
    X_tensor = torch.tensor(X, dtype=torch.float32).to(device)
    y_tensor = torch.tensor(y, dtype=torch.float32).to(device)

    
    class TransformerTimeSeries(nn.Module):
        def __init__(self, input_size, d_model, nhead, num_layers, window_size):
            super(TransformerTimeSeries, self).__init__()
            self.d_model = d_model
            
            self.input_proj = nn.Linear(input_size, d_model)
            
            self.pos_encoder = nn.Parameter(torch.zeros(window_size, d_model))
            
            encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead)
            self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
           
            self.decoder = nn.Linear(d_model, input_size)

        def forward(self, src):
            
            x = self.input_proj(src) 
          
            x = x + self.pos_encoder
            
            x = x.transpose(0, 1)
            
            x = self.transformer_encoder(x) 
            
            x_last = x[-1]  
            out = self.decoder(x_last)  
            return out
  
    input_size = 3
    d_model = 64
    nhead = 4
    num_layers = 2

    model = TransformerTimeSeries(input_size, d_model, nhead, num_layers, window_size).to(device)

  
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

   
    num_epochs = 10000
    for epoch in range(num_epochs):
        model.train()
        optimizer.zero_grad()
        output = model(X_tensor)  
        loss = criterion(output, y_tensor)
        loss.backward()
        optimizer.step()
       
    last_window = data_scaled[:, -window_size:].T
    last_window_tensor = torch.tensor(last_window, dtype=torch.float32).unsqueeze(0).to(device) 
    model.eval()
    with torch.no_grad():
        pred_scaled = model(last_window_tensor) 
    pred_scaled_np = pred_scaled.squeeze(0).cpu().numpy()

    
    pred_original = scaler.inverse_transform(pred_scaled_np.reshape(1, -1))



    predictions[n - 20, 0:3] = pred_original
    predictions[n - 20, 3] = n + 1
    print(n)

respath = 'results/window=%d/' % (arguments.windowsize)
sio.savemat(respath + 'transformer_four_week.mat', {'pred': predictions})
