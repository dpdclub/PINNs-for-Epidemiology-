import numpy as np
import scipy.io
from argparse import ArgumentParser


parser = ArgumentParser()
parser.add_argument("--windowsize", type=int, default=5)
arguments = parser.parse_args()
print(arguments)

respath = 'results/window=%d/' % (arguments.windowsize)

for i in range(1, 72):

    lstm_data = scipy.io.loadmat(respath + 'transformer_one_week.mat')
    pred = lstm_data['pred'].T  
    cases1 = pred[0, :]
    cases1 = cases1[cases1 != 0] 
    deaths1 = pred[1, :]
    deaths1 = deaths1[deaths1 != 0]  
    hospitalized1 = pred[2, :]
    hospitalized1 = hospitalized1[hospitalized1 != 0]  
    

    lstm2_data = scipy.io.loadmat(respath + 'transformer_two_week.mat')
    pred2 = lstm2_data['pred'].T  
    cases2 = pred2[0, :]
    cases2 = cases2[cases2 != 0]  
    deaths2 = pred2[1, :]
    deaths2 = deaths2[deaths2 != 0] 
    hospitalized2 = pred2[2, :]
    hospitalized2 = hospitalized2[hospitalized2 != 0]  
    
   
    lstm3_data = scipy.io.loadmat(respath + 'transformer_three_week.mat')
    pred3 = lstm3_data['pred'].T  
    cases3 = pred3[0, :]
    cases3 = cases3[cases3 != 0]  
    deaths3 = pred3[1, :]
    deaths3 = deaths3[deaths3 != 0] 
    hospitalized3 = pred3[2, :]
    hospitalized3 = hospitalized3[hospitalized3 != 0]  #
    
    
    

    gt_data = scipy.io.loadmat('groundtruth_data_weekly_avg.mat')


    cases = np.squeeze(gt_data['cases'])[20:]
    deaths = np.squeeze(gt_data['deaths'])[20:]
    hospitalized = np.squeeze(gt_data['hospitalized'])[20:]


    casesX = np.concatenate([cases[:16+i ], [cases1[i - 1]], [cases2[i - 1]],[cases3[i - 1]]])
    deathsX = np.concatenate([deaths[:16+i ], [deaths1[i - 1]], [deaths2[i - 1]],[deaths3[i - 1]]])
    hospitalizedX = np.concatenate([hospitalized[:16+i], [hospitalized1[i - 1]], [hospitalized2[i - 1]],[hospitalized3[i - 1]]])
    

    deaths = deathsX
    cases = casesX
    hospitalized = hospitalizedX
    

    filename = f'middata/three_week_{19 + i}.mat'
    scipy.io.savemat(filename, {'cases': cases, 'deaths': deaths, 'hospitalized': hospitalized})
