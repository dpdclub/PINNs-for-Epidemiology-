import torch
import torch.nn as nn
import torch.optim as optim
import scipy.io as sio
import numpy as np
from sklearn.preprocessing import StandardScaler
import warnings
from argparse import ArgumentParser


parser = ArgumentParser()
parser.add_argument("--windowsize", type=int, default=5)
arguments = parser.parse_args()
print(arguments)

warnings.filterwarnings('ignore') 
device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")


predictions = np.zeros([72, 4])
for K in range(18, 90):
    filename=f"middata/one_week_{K}.mat"
    data = sio.loadmat(filename)
    Zr_data = data["cases"].T
    Dr_data = data["deaths"].T
    A_data = data["hospitalized"].T  

    Zr_data[Zr_data <= 0] = 0
    Dr_data[Dr_data <= 0] = 0
    A_data[A_data <= 0] = 0

    scaler_Zr = StandardScaler()
    scaler_Dr = StandardScaler()
    scaler_A = StandardScaler()

    Zr_data = scaler_Zr.fit_transform(Zr_data)
    Dr_data = scaler_Dr.fit_transform(Dr_data)
    A_data = scaler_A.fit_transform(A_data)

    # s = [120000, 500, 2000] # scales
    # Zr_data = Zr_data / s[0]
    # Dr_data = Dr_data / s[1]
    # A_data = A_data / s[2]

    data = torch.stack([torch.tensor(Zr_data, dtype=torch.float32),
                        torch.tensor(Dr_data, dtype=torch.float32),
                        torch.tensor(A_data, dtype=torch.float32)], dim=-1).squeeze(-2)

    # window_size = 7
    window_size = arguments.windowsize

    inputs = []
    targets = []
    for i in range(len(data) - window_size):
        inputs.append(data[i:i + window_size,:].numpy())
        targets.append(data[i + window_size,:].numpy())

    inputs = torch.tensor(inputs, dtype=torch.float32).to(device)
    targets = torch.tensor(targets, dtype=torch.float32).to(device)


    class RNNPredictor(nn.Module):
        def __init__(self, input_size=3, hidden_size=50, num_layers=2, output_size=3):
            super(RNNPredictor, self).__init__()
            self.hidden_size = hidden_size
            self.num_layers = num_layers
            self.rnn = nn.RNN(input_size, hidden_size, num_layers, batch_first=True)
            self.fc = nn.Linear(hidden_size, output_size)
            # self.relu = nn.ReLU()

        def forward(self, x):
            h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device)
            out, _ = self.rnn(x, h0)
            out = self.fc(out[:, -1, :])
            # out = self.relu(out)
            # out = torch.square(out)
            return out

    model = RNNPredictor().to(device)


    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)


    num_epochs = 10000
    for epoch in range(num_epochs):
        model.train()
        optimizer.zero_grad()
        output = model(inputs)
        loss = criterion(output, targets)
        loss.backward()
        optimizer.step()


    last_window = torch.tensor(data[-window_size:], dtype=torch.float32).to(device).unsqueeze(0)
    model.eval()
    with torch.no_grad():
        prediction = model(last_window)

    predicted_values = prediction.cpu().numpy().squeeze()

    predicted_values[0] = scaler_Zr.inverse_transform(predicted_values[0].reshape(1, -1))
    predicted_values[1] = scaler_Dr.inverse_transform(predicted_values[1].reshape(1, -1))
    predicted_values[2] = scaler_A.inverse_transform(predicted_values[2].reshape(1, -1))

    # predictions should be non-negative
    for i in range(3):
        predicted_values[i] = max(1e-6, predicted_values[i])

    # predicted_values[0] = predicted_values[0].reshape(1, -1) * s[0]
    # predicted_values[1] = predicted_values[1].reshape(1, -1) * s[1]
    # predicted_values[2] = predicted_values[2].reshape(1, -1) * s[2]

    predictions[K - 18, 0:3] = predicted_values
    predictions[K - 18, 3] = K + 1  
    print(K)


respath = 'results/window=%d/' % (arguments.windowsize)
sio.savemat(respath + 'RNN_two_week.mat', {'pred': predictions})
