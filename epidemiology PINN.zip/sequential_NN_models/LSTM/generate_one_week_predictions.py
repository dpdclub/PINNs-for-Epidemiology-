import numpy as np
import scipy.io
from argparse import ArgumentParser


parser = ArgumentParser()
parser.add_argument("--windowsize", type=int, default=5)
arguments = parser.parse_args()
print(arguments)

respath = 'results/window=%d/' % (arguments.windowsize)

for i in range(1, 74):

    lstm_data = scipy.io.loadmat(respath + 'LSTM_one_week.mat')
    gt_data = scipy.io.loadmat('groundtruth_data_weekly_avg.mat')

    
    cases = np.squeeze(gt_data['cases'])[20:]
    deaths = np.squeeze(gt_data['deaths'])[20:]
    hospitalized = np.squeeze(gt_data['hospitalized'])[20:]


    pred = lstm_data['pred'].T

    
    cases1 = pred[0, :]
    cases1 = cases1[cases1 != 0]

    deaths1 = pred[1, :]
    deaths1 = deaths1[deaths1 != 0]

    hospitalized1 = pred[2, :]
    hospitalized1 = hospitalized1[hospitalized1 != 0]


    cases2 = np.concatenate((cases[:16 + i], [cases1[i - 1]]))
    deaths2 = np.concatenate((deaths[:16 + i], [deaths1[i - 1]]))
    hospitalized2 = np.concatenate((hospitalized[:16 + i], [hospitalized1[i - 1]]))

    
    cases = cases2
    deaths = deaths2
    hospitalized = hospitalized2

    
    filename = f"middata/one_week_{17 + i}.mat"


    scipy.io.savemat(filename, {'cases': cases, 'deaths': deaths, 'hospitalized': hospitalized})
